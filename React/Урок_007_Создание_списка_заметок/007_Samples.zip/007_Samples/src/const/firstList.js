export const firstListItems = [
  {
    id: 'uniqueA',
    text: 'Dan'
  },
  {
    id: 'uniqueB',
    text: 'Lisa'
  },
  {
    id: 'uniqueC',
    text: 'Lena'
  },
];