export const iconTypes = {
  plus: 'plus',
  cross: 'cross'
}